/* header.h */

#ifndef _HEADER_H_
#define _HEADER_H_

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/types.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <time.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdbool.h>
#include <sys/ipc.h>
#include <sys/msg.h>

/* Defines */
/* Data Types */
typedef int INT;
typedef char CHAR;
typedef void VOID;
typedef bool BOOL;
typedef long LONG;

/* Server Socket Information */
struct sockaddr_in gServer_Sock_ad;

/* Client Socket Information */
struct sockaddr_in gClient_Sock_ad;

enum{
	CONNECTREQ = 0,
	CONNECTRESP,
	ISALIVE,
	YESALIVE,
	PEERUPDATE,
	TIMEOUT
};

#define SUCCESS 			1
#define FAILURE 			0

#define FALSE				0
#define TRUE				1

#define DATASIZE 			1024
#define GRAPHSIZE 			4
#define MAXPORT				4
#define MAXNODE 			4

/* Message queue */
#define MSG_SIZE 			1024
#define KEY_NAME 			"./msg"
#define KEY					60

#define EVENT				1

/* Data Structures */
/* UDP packet */
typedef struct packet	
{
	struct sockaddr_in *Client;
	INT 	iRequestType;	
	INT		iPortId;
	INT		pData[GRAPHSIZE][GRAPHSIZE]; 
}PACKET;

typedef struct queue
{
	LONG	lType;
	PACKET 	*Packet;
}MSGQ;

/* Connection */
typedef struct connection
{
	INT		iNodeId;
	INT 	iPortId;
}CONNECTION;

/* Vertex's */
typedef struct vertex {
	INT  iEdge;
	INT	 iPortId;
	BOOL bVisited;
}VERTEX;

/* Function Prototype */
VOID *CreateServerSocket();
VOID *CreateClientSocket();
INT AddVertex(INT,INT);
VOID AddEdge(INT,INT);
VOID *StartTimer(VOID *);
VOID *MsgQueue();
INT Timeout_CB();
INT ProcessEvents(PACKET *);
INT CreateMessageQueue();
VOID FindSPDijstra(INT iGraph[GRAPHSIZE][GRAPHSIZE], INT iSrc);
INT MinDistance(INT Dist[], BOOL sptSet[]);
INT printSolution(INT Dist[], INT in);
INT AdjustGraph(INT PeerGraph[GRAPHSIZE][GRAPHSIZE]);
INT GetAdjUnvisitedVertex(INT Graph[GRAPHSIZE][GRAPHSIZE],INT VertexIndex);
INT	FindSPT(INT Graph[GRAPHSIZE][GRAPHSIZE]);
INT find(INT belongs[],INT vertexno);
VOID union1(INT belongs[],INT c1,INT c2);
#endif /*_HEADER_H_*/
