#include<header.h>

/*Server Desc*/
INT gServer_Des = 0;
/*Client Desc*/
INT gClient_Des = 0;

/*Vertexs*/
VERTEX *ListVertex[MAXNODE];
INT iVertexCount = 0;

/* Graph */
INT giGraph[GRAPHSIZE][GRAPHSIZE];

/* Ports */
INT giPortIds[MAXPORT];

/* Own Node ID */
INT giNodeID;

/* Message Queue ID */
INT giMsgQId;

int main(int argc, char *argv[])
{
	INT			iRetVal = FAILURE;
	INT 		iLoop = 0, iLoop2 = 0;
	INT			iNewVertex = 0;
	CHAR		cExit;
	pthread_t 	pthread_id[10];
	INT 		iTimeInSec = 0;

	if (argc != 3 )
	{
		printf("Usage: ./EXE NodeID PortID\n");
		return FAILURE;
	}

	/* Own Node id */
	giNodeID = atoi(argv[1]);

	/* Own Port is always at index 0 */
	giPortIds[0] = atoi(argv[2]);

	printf("Initiating the Node\n");
	printf("Node ID : %d, Port ID : %d\n",giNodeID,giPortIds[0]);

	memset (&gServer_Sock_ad, 0, sizeof(struct sockaddr_in));
	memset (&gClient_Sock_ad, 0, sizeof(struct sockaddr_in));

	/*Init Graph to 0*/
	for(iLoop=0; iLoop<GRAPHSIZE; iLoop++) 
	{
		for(iLoop2=0; iLoop2<GRAPHSIZE; iLoop2++)
		{
			giGraph[iLoop][iLoop2] = 0;
		}
	}
	iLoop=0;
	iLoop2=0;

	iRetVal = CreateMessageQueue();
	if (iRetVal != SUCCESS)
	{
		printf("main : CreateMessageQueue failed\n");
		return FAILURE;
	}

	iRetVal = pthread_create(&pthread_id[2], NULL, MsgQueue, NULL);
	if(iRetVal != 0)
	{
		printf("main : Create Server Socket Failed\n");
		return FAILURE;
	}
	
	/* Create a UPD Socket to recevie the events */
	iRetVal = pthread_create(&pthread_id[0], NULL, CreateServerSocket, NULL); 
	if(iRetVal != 0)
	{
		printf("main : Create Server Socket Failed\n");
		return FAILURE;
	}

	iRetVal = pthread_create(&pthread_id[3], NULL, CreateClientSocket, NULL);
	if(iRetVal != 0)
	{
		printf("main : Create Client Socket Failed\n");
		return FAILURE;
	}

	/* Adding own Vertex */
	AddVertex(giNodeID, giPortIds[0]);

	/*while(cExit != 'Y')
	  {*/
	printf("Please provide the information\n");
	printf("what the other three vertex to which it is connected?\n");
	for (iLoop=0; iLoop<3; iLoop++)
	{
		printf("Vertex : ");
		scanf("%d",&iNewVertex);

		printf("Please Enter %d vertex port Number: ",iNewVertex);
		scanf("%d",&giPortIds[iLoop+1]);
		iRetVal = AddVertex(iNewVertex, giPortIds[iLoop+1]);
		if (iRetVal != SUCCESS)
		{
			printf("main : Addvertex failed\n");
			return FAILURE;
	/* Create a UPD Socket to recevie the events */
	iRetVal = pthread_create(&pthread_id[0], NULL, CreateServerSocket, NULL); 
	if(iRetVal != 0)
	{
		printf("main : Create Server Socket Failed\n");
		return FAILURE;
	}
		}

		/* Add Edge between source vertex and newly added vertex */
		AddEdge (giNodeID, iNewVertex);
	}
	/*while ((getchar()) != '\n');
	  printf("Exit? Y/N\n");
	  scanf("%c",&cExit);
	  }*/
	iLoop=0;

	/*for(iLoop=0;iLoop<6;iLoop++)
	  {
	  for(iLoop2=0;iLoop2<6;iLoop2++)
	  {
	  printf("%d ",giGraph[iLoop][iLoop2]);
	  }
	  printf("\n");
	  }*/

	/* Initiate the Timer */
	iTimeInSec = 10;
	iRetVal = pthread_create(&pthread_id[1], NULL, StartTimer, (VOID *)&iTimeInSec);
	if(iRetVal != 0)
	{
		printf("main : error creating the thread\n");
		return FAILURE;
	}

	for (iLoop=0;iLoop<10;iLoop++)
	{
		iRetVal = pthread_join(pthread_id[iLoop], NULL);
		if(iRetVal)
		{
			printf("main : Pthread_join failed\n");
			return FAILURE;
		}
	}
	close (gServer_Des);
	close (gClient_Des);
	return SUCCESS;
}
