#include <header.h>

/*Server Desc*/
extern INT gServer_Des;
/*Client Desc*/
extern INT gClient_Des;

extern VERTEX *ListVertex[MAXNODE];
extern INT iVertexCount;

extern INT giGraph[GRAPHSIZE][GRAPHSIZE];
extern INT giPortIds[MAXPORT];
extern INT giNodeID;
extern INT giMsgQId;

pthread_mutex_t pthread_mutex = PTHREAD_MUTEX_INITIALIZER;

/* Create Socket for Server */
VOID* CreateServerSocket()
{
	INT	 		iRetVal = FAILURE, iRead = 0;
	PACKET		PacketRecv;
	MSGQ		MsgQ;
	struct sockaddr_in Client;
	socklen_t iLen = sizeof Client;

	memset (&Client, 0 , sizeof(Client));

	/*PacketRecv.pData = (VOID *) malloc (1024);
	if (PacketRecv.pData == NULL)
	{
		printf("StartTimer : malloc failed\n");
		pthread_exit(NULL);
	}
	memset(PacketRecv.pData, 0 , sizeof(PacketRecv.pData));*/

	gServer_Des = socket (AF_INET, SOCK_DGRAM, 0);
	if (gServer_Des < 0)
	{
		printf("CreateServerSocket : Socket Failed\n");
		pthread_exit(NULL);
	}

	gServer_Sock_ad.sin_family = AF_INET;
	gServer_Sock_ad.sin_port = htons(giPortIds[0]);
  	gServer_Sock_ad.sin_addr.s_addr = inet_addr("127.0.0.1");

	iRetVal = bind (gServer_Des, (struct sockaddr *)&gServer_Sock_ad, sizeof(gServer_Sock_ad));
	if (iRetVal < 0)
	{
		printf("CreateServerSocket : bind Failed\n");
		pthread_exit(NULL);
	}

	while (1)
	{
		iRead = recvfrom (gServer_Des, &PacketRecv, sizeof(PACKET),0, (struct sockaddr*)&Client, &iLen);
		if(iRead == 0)
		{
			printf("CreateServerSocket : Read failed\n");
			pthread_exit(NULL);
		}
		PacketRecv.Client = (struct sockaddr_in*)&Client;
		printf("%d",ntohs(PacketRecv.Client->sin_port));
		MsgQ.lType = EVENT;
		MsgQ.Packet = &PacketRecv;
		iRetVal = msgsnd (giMsgQId, &MsgQ, sizeof(MsgQ), 0);
		if (iRetVal == -1)
		{
			printf("CreateServerSocket : Msg Send Failed\n");
			pthread_exit(NULL);
		}
		//free(PacketRecv.pData);
	}
	pthread_exit(NULL);
}

/* Create Socket for Server */
VOID * CreateClientSocket()
{
	struct sockaddr_in Server;
	PACKET PacketRecv;
	INT iRead =0, iRetVal = 0;
	MSGQ MsgQ;
	socklen_t iLen = sizeof(struct sockaddr_in);
	gClient_Des = socket (AF_INET, SOCK_DGRAM, 0);
	if (gServer_Des < 0)
	{
		printf("CreateClientSocket : Socket Failed\n");
		pthread_exit(NULL);
	}

	while(1)
	{
		iRead = recvfrom (gClient_Des, &PacketRecv, sizeof(PACKET),0, (struct sockaddr*)&Server, &iLen);
		if(iRead == 0)
		{
			printf("CreateClientSocket : Read failed\n");
			pthread_exit(NULL);
		}
		PacketRecv.Client = (struct sockaddr_in*)&Server;
		printf("%d",ntohs(PacketRecv.Client->sin_port));
		MsgQ.lType = EVENT;
		MsgQ.Packet = &PacketRecv;
		iRetVal = msgsnd (giMsgQId, &MsgQ, sizeof(MsgQ), 0);
		if (iRetVal == -1)
		{
			printf("CreateClientSocket : Msg Send Failed\n");
			pthread_exit(NULL);
		}
	}

	pthread_exit(NULL);
}

INT AddVertex(INT iVertex, INT iPortId)
{
	VERTEX *Vertex = (VERTEX *) malloc(sizeof(VERTEX));
	if (Vertex == NULL)
	{
		printf("AddVertex :  malloc failed\n");
		return FAILURE;
	}
	Vertex->iEdge = iVertex;  
	Vertex->bVisited = FALSE;    
	Vertex->iPortId = iPortId;

	ListVertex[iVertexCount++] = Vertex;
	return SUCCESS;
}

VOID AddEdge(INT iStart, INT iEnd) 
{
	giGraph[iStart][iEnd] = 1;
	giGraph[iEnd][iStart] = 1;
}

VOID *StartTimer(VOID *Args)
{
	/* function pointer */
	PACKET 		DataPacket;
	struct sockaddr_in Server;
	memset (&Server, 0 , sizeof(Server));

	DataPacket.iRequestType = TIMEOUT;
	/*DataPacket.pData = (VOID *) malloc (1024);
	if (DataPacket.pData == NULL)
	{
		printf("StartTimer : malloc failed\n");
		pthread_exit(0);
	}
	memset(DataPacket.pData, 0 , sizeof(DataPacket.pData));*/

	/* cast the seconds passed in to int and 
	 *  set this for the period to wait */
	INT iSeconds = *((INT*) Args);
	while (1)
	{
		printf("Waiting for %d\n", iSeconds);

		sleep(iSeconds);
		/* call the cb to inform the user time is out */

		Server.sin_family = AF_INET;
		Server.sin_port = htons(giPortIds[0]);
		Server.sin_addr.s_addr = inet_addr("127.0.0.1");

		sendto(gClient_Des, &DataPacket, sizeof(PACKET), 0, (struct sockaddr*)&Server, sizeof(Server));
	}

	free(DataPacket.pData);
	pthread_exit(NULL);
}

VOID* MsgQueue()
{
	MSGQ        MsgQ;
	while (1)
	{
		msgrcv(giMsgQId, (MSGQ *)&MsgQ, sizeof(MSGQ), EVENT, 0);
		ProcessEvents(MsgQ.Packet);
	}
}

INT ProcessEvents(PACKET *PacketData)
{
	INT iEvent = 0;
	INT iLoop = 0, iLoop2= 0;
	PACKET      DataPacket;
	struct sockaddr_in Server;
	INT PeerGraph[GRAPHSIZE][GRAPHSIZE];

	iEvent = PacketData->iRequestType;
	switch(iEvent)
	{
		case TIMEOUT:
			printf("Time out Event Recevied\n");
			memset (&Server, 0 , sizeof(Server));

			DataPacket.iRequestType = ISALIVE;
	/*DataPacket.pData = (VOID *) malloc (1024);
			if (DataPacket.pData == NULL)
			{
				printf("StartTimer : malloc failed\n");
				pthread_exit(0);
			}
			memset(DataPacket.pData, 0 , sizeof(DataPacket.pData));*/

			/* Check if the Peers are connected */
			/* Each Vertex is connected with 3 different Vertexs */
			for (iLoop=1;iLoop<MAXPORT;iLoop++)
			{
				Server.sin_family = AF_INET;
				Server.sin_port = htons(giPortIds[iLoop]);
				printf("Sending %d\n",giPortIds[iLoop]);
				Server.sin_addr.s_addr = inet_addr("127.0.0.1");
				sendto(gClient_Des, &DataPacket, sizeof(PACKET), 0, (struct sockaddr*)&Server, sizeof(Server));
			}
			iLoop=0;
			//free(DataPacket.pData);
			break;
		case ISALIVE:
			printf("ISAlive Event Received\n");

			DataPacket.iRequestType = YESALIVE;
			/*DataPacket.pData = (VOID *) malloc (1024);
			if (DataPacket.pData == NULL)
			{
				printf("StartTimer : malloc failed\n");
				pthread_exit(0);
			}
			memset(DataPacket.pData, 0 , sizeof(DataPacket.pData));*/

			sendto(gServer_Des, &DataPacket, sizeof(PACKET), 0, (struct sockaddr*)PacketData->Client, sizeof(struct sockaddr_in));
			break;
		case YESALIVE:
			printf("YESALIVE Event Recevived\n");

			/*Update with the Graph details*/
			DataPacket.iRequestType = PEERUPDATE;
			/*DataPacket.pData = (VOID *) malloc (1024);
			if (DataPacket.pData == NULL)
			{
				printf("StartTimer : malloc failed\n");
				pthread_exit(0);
			}*/
			memset(DataPacket.pData, 0 , sizeof(DataPacket.pData));
			memcpy(DataPacket.pData, giGraph, sizeof(giGraph));
			sendto(gClient_Des, &DataPacket, sizeof(PACKET), 0, (struct sockaddr*)PacketData->Client, sizeof(struct sockaddr_in));
			break;
		case PEERUPDATE:
			printf("Peer Update\n");
			/*Update the graph*/
			memcpy(PeerGraph,DataPacket.pData,sizeof(PeerGraph));
			for(iLoop=0;iLoop<6;iLoop++)
			{
				for(iLoop2=0;iLoop2<6;iLoop2++)
				{
					printf("%d ",PeerGraph[iLoop][iLoop2]);
				}
				printf("\n");
			}

			pthread_mutex_lock(&pthread_mutex);
			AdjustGraph(PeerGraph);	/*Update local graph with peer graph*/
			FindSPDijstra(giGraph,giNodeID);
			FindSPT(giGraph);
			pthread_mutex_unlock(&pthread_mutex);
			break;

		default:
			printf("default\n");
			break;
	}
	return SUCCESS;
}

INT CreateMessageQueue()
{
	INT iKey=0;

	if ((iKey = ftok(KEY_NAME, KEY)) == -1)
	{
		printf("CreateMessageQueue : create key failed\n");
		return FAILURE;
	}
	
	if ((giMsgQId = msgget(iKey, 0666|IPC_CREAT)) == -1)
	{
		perror("ftok");
		printf("CreateMessageQueue : Error creating MSG Q\n");
		return FAILURE;
	}
	
	return SUCCESS;
}
