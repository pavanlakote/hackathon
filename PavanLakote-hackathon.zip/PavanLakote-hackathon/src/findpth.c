#include <header.h>

extern VERTEX *ListVertex[MAXNODE];
extern INT iVertexCount;

/* Graph */
extern INT giGraph[GRAPHSIZE][GRAPHSIZE];

typedef struct edge
{
	INT u,v,w;
}Edge;

typedef struct edgelist
{
	Edge data[MAXNODE];
	int n;
}EdgeList;
 
EdgeList Elist,SpanList;

INT queue[GRAPHSIZE];
INT rear = -1;
INT front = 0;
INT queueItemCount = 0;

VOID Insert(INT data);
INT RemoveData(VOID);
BOOL isQueueEmpty();

VOID Insert(INT data) {
	queue[++rear] = data;
	queueItemCount++;
}

INT RemoveData() 
{
	queueItemCount--;
	return queue[front++]; 
}

BOOL isQueueEmpty() {
	return queueItemCount == 0;
}

VOID FindSPDijstra(INT iGraph[GRAPHSIZE][GRAPHSIZE], INT iSrc)
{
	INT iLoop = 0;
	INT iu = 0, iv = 0;
	/* Dist will be hold in Shorttest path*/
	INT Dist[GRAPHSIZE];

	/*To set the vestex as visited */
	BOOL sptSet[GRAPHSIZE]; 

	/* Initialize all Distances as INFINITE and stpSet[] as false */
	for (iLoop = 0; iLoop < GRAPHSIZE; iLoop++)
	{
		Dist[iLoop] = GRAPHSIZE, sptSet[iLoop] = false;
	}
	iLoop = 0;

	/* Dist to own is 0 */
	Dist[iSrc] = 0;

	for (iLoop = 0; iLoop < GRAPHSIZE-1; iLoop++)
	{
		/*Get the minium distanc*/
		iu = MinDistance(Dist, sptSet);

		/*mask as visited*/
		sptSet[iu] = true;

		for (iv = 0; iv < GRAPHSIZE; iv++)
		{
			if (!sptSet[iv] && iGraph[iu][iv] && Dist[iu] !=GRAPHSIZE 
					&& Dist[iu]+iGraph[iu][iv] < Dist[iv])
				Dist[iv] = Dist[iu] + iGraph[iu][iv];
		}
	}
}

INT MinDistance(INT Dist[], BOOL sptSet[])
{
	INT iMin = GRAPHSIZE, MinIndex; 
	INT iv =0;

	for (iv = 0; iv < GRAPHSIZE; iv++)
		if (sptSet[iv] == false && Dist[iv] <= iMin)
			iMin = Dist[iv], MinIndex = iv;

	return MinIndex;
}

INT printSolution(INT Dist[], INT in)
{
	INT iLoop = 0;
	for (iLoop = 0; iLoop < GRAPHSIZE; iLoop++)
		printf("%d \t\t %d\n", iLoop, Dist[iLoop]);
	return SUCCESS;
}

INT AdjustGraph(INT PeerGraph[GRAPHSIZE][GRAPHSIZE])
{
	INT iUnvisited;
	INT TempVertex;
	/*Own Node*/
	ListVertex[0]->bVisited = TRUE;
	Insert(0);

	while(!isQueueEmpty())
	{
		TempVertex = RemoveData();

		while((iUnvisited = GetAdjUnvisitedVertex(giGraph, TempVertex)) != -1) 
		{    
			ListVertex[iUnvisited]->bVisited = TRUE;
			Insert(iUnvisited);               
		}
		if(iUnvisited == -1)
		{
			iUnvisited = GetAdjUnvisitedVertex(PeerGraph, TempVertex);
			if (iUnvisited != -1)
			{
				/*add or update*/
				giGraph[TempVertex][iUnvisited] = PeerGraph[TempVertex][iUnvisited];
			}
			else
			{
				/*remove node*/
				giGraph[TempVertex][iUnvisited] = 0;
			}
		}
	}


	return SUCCESS;
}

INT GetAdjUnvisitedVertex(INT Graph[GRAPHSIZE][GRAPHSIZE],INT VertexIndex) 
{
	INT iLoop;

	for(iLoop = 0; iLoop < iVertexCount; iLoop++) {
		if(Graph[VertexIndex][iLoop] == 1 && ListVertex[iLoop]->bVisited == false)
			return iLoop;
	}

	return -1;
}
INT Sort(INT Vertex)
{
	INT iLoop=0,iLoop2=0;
	Edge Temp;

	for (iLoop=0;iLoop<Vertex;iLoop++)
		for (iLoop2=0;iLoop2<Vertex-1;iLoop2++)
			if(Elist.data[iLoop2].w > Elist.data[iLoop2+1].w)
			{
				Temp = Elist.data[iLoop2];
				Elist.data[iLoop2]=Elist.data[iLoop2+1];
				Elist.data[iLoop2]=Temp;
			}
	return SUCCESS;
}

INT FindSPT(INT Graph[GRAPHSIZE][GRAPHSIZE])
{
	INT iLoop=0, iLoop2=0;	
	INT Vertex=0;
	INT cno1=0,cno2=0;
	INT belongs[MAXNODE];

	printf("Please input the weight\n");
	for (iLoop=0;iLoop<GRAPHSIZE;iLoop++)
		for(iLoop2=0;iLoop2<GRAPHSIZE;iLoop2++)
			if(Graph[iLoop][iLoop2] != 0)
			{
				Elist.data[Vertex].u=iLoop;
				Elist.data[Vertex].v=iLoop2;
				scanf("%d",&Elist.data[Vertex].w);
				Vertex++;
			}

	Sort(Vertex);

	iLoop=0;
	iLoop2=0;

	for (iLoop=0;iLoop<Elist.n;iLoop++)
	{
		cno1=find(belongs,Elist.data[iLoop].u);
		cno2=find(belongs,Elist.data[iLoop].v);

		if(cno1!=cno2)
		{
			SpanList.data[SpanList.n]=Elist.data[iLoop];
			SpanList.n=SpanList.n+1;
			union1(belongs,cno1,cno2);
		}
	}
	
	return SUCCESS;
}

INT find(INT belongs[],INT vertexno)
{
	    return(belongs[vertexno]);
}

VOID union1(INT belongs[],INT c1,INT c2)
{
	INT i;

	for(i=0;i<MAXNODE;i++)
		if(belongs[i]==c2)
			belongs[i]=c1;
}
